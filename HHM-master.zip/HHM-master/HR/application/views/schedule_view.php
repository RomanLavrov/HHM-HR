<div style="height:300px; width: 600px; background: red;">
schedule
</div>