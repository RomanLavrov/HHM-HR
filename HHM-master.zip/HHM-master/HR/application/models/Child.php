<?php

class Child{
    public $idParent;
    public $ChildName;
    public $ChildLastName;
    public $ChildBirthday;
}