<?php
class SwissVisit{
      public $idEmployee;
      public $StartDate;
      public $EndDate;
      public $Location;
      public $Accommodation;
      public $Goal;
      public $Group;
}
?>